package com.utilities;

import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;


public class PropertiesReader {

	
	//Get API
	public String sampleGetAPIUrl =  "https://reqres.in/api/users?page=2";
	
	//Post API
	public String samplePostAPIUrl = "https://reqres.in/api/users";
	
	//Environments
	public String env = null;
	
	private static PropertiesReader propertiesReader_instance = null;

	
	private PropertiesReader() {

		Properties appConfigPropertySet = new Properties();
		Properties envConfigPropertySet = new Properties();

		try {

			// Read and load properties file indicating the desired environment
			InputStream appConfigPropertyStream = PropertiesReader.class
					.getResourceAsStream("/config/baseAppConfig.properties");
			appConfigPropertySet.load(appConfigPropertyStream);

			// Read and load environment specific configuration
			InputStream envConfigPropertyStream = null;

			// check if current environment is defined (QA, Integration or Staging)
			if(System.getProperty("testenvironment") != null){
				envConfigPropertyStream = PropertiesReader.class
						.getResourceAsStream("/config/"
								+ System.getProperty("testenvironment")
								+ "/appConfig.properties");
				this.env = System.getProperty("testenvironment");
				System.out.println("********'ENVIRONMENT Details taken from Runtime Property'********");
				System.out.println("********'"+System.getProperty("testenvironment")+" ENVIRONMENT'********");
			}
			else {
				envConfigPropertyStream = PropertiesReader.class
						.getResourceAsStream("/config/"
								+ appConfigPropertySet.getProperty("CurrentEnvironment")
								+ "/appConfig.properties");
				this.env = appConfigPropertySet.getProperty("CurrentEnvironment");
				System.out.println("********'ENVIRONMENT Details taken from Baseapp config property file'********");
				System.out.println("********'"+appConfigPropertySet.getProperty("CurrentEnvironment")+" ENVIRONMENT'********");
			}

			envConfigPropertySet.load(envConfigPropertyStream);
			this.sampleGetAPIUrl = envConfigPropertySet.getProperty("APITestPage")+"users?page=2";
			this.samplePostAPIUrl = envConfigPropertySet.getProperty("APITestPage")+"users";
			
					
			envConfigPropertyStream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static PropertiesReader getInstance(){

		if(propertiesReader_instance == null){
			propertiesReader_instance = new PropertiesReader();
		}
		return propertiesReader_instance;
	}
}
