package com.utilities;

import org.json.JSONObject;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

public class RestAssuredClient {

	public static class RequestType {
		public static final int GET_REQUEST = 0;
		public static final int POST_REQUEST = 1;
		public static final int DELETE_REQUEST = 2;
		public static final int PUT_REQUEST = 3;
	}

	//Request prestep
	public static RequestSpecification getCommonSpec() {
		RequestSpecification rSpec = SerenityRest.given().relaxedHTTPSValidation().log().uri().and().log().body();
		rSpec.contentType(ContentType.JSON);
		return rSpec;
	}

	//Convert POJO to JSON
	protected static JSONObject createJSONPayload(Object pojo) {
		return new JSONObject(pojo);
	}

	@Step
	public static Response sendRequest(RequestSpecification request, int requestType, Object pojo) {
		Response response;

		// Add the Json to the body of the request
		if (pojo != null) {
			String payload = createJSONPayload(pojo).toString();
			request.body(payload);
		}

		switch (requestType) {
		case RequestType.POST_REQUEST:
			if (request == null) {
				response = SerenityRest.when().post();
			} else {
				response = request.post();
			}

			break;
		case RequestType.DELETE_REQUEST:
			if (request == null) {
				response = SerenityRest.when().delete();
			} else {
				response = request.delete();
			}
			break;
		case RequestType.PUT_REQUEST:
			if (request == null) {
				response = SerenityRest.when().put();
			} else {
				response = request.put();
			}
			break;
		case RequestType.GET_REQUEST:
		default:
			if (request == null) {
				response = SerenityRest.when().get();
			} else {
				response = request.get();
			}
			break;
		}

		System.out.println("Response Body: ");
		SerenityRest.then().log().status().and().log().body();
		return response;
	}
}