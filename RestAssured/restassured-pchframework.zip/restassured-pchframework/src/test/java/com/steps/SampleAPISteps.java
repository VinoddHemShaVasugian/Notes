package com.steps;

import static org.hamcrest.Matchers.equalTo;

import org.junit.Assert;

import com.request.dto.PostAPIRequestDTO;
import com.response.dto.GetAPIParentResponse;
import com.response.dto.PostAPIParentResponse;
import com.utilities.PropertiesReader;
import com.utilities.RestAssuredClient;

import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import net.serenitybdd.rest.SerenityRest;

public class SampleAPISteps extends RestAssuredClient {

	PostAPIRequestDTO postAPIRequest = null;
	Response response = null;
	ResponseBody responseBody = null;

	//Call Get API
	public void getSampleAPIJSONDetails() {
		response = sendRequest(getCommonSpec().baseUri(PropertiesReader.getInstance().sampleGetAPIUrl), RequestType.GET_REQUEST, null);
	}

	// Verify Get API Response Directly  
	public void verifySampleGetAPIResponseDirectly(DataTable responseTable){
		String httpCode = responseTable.asMaps().get(0).get("HttpCode");

		switch(httpCode){
		case "200":	
			SerenityRest.restAssuredThat(response -> response.statusCode(Integer.parseInt(httpCode)));
			SerenityRest.restAssuredThat(response -> response.body("page", equalTo(1)));
			SerenityRest.restAssuredThat(response -> response.body("data[0].email", equalTo("george.bluth@reqres.in")));
			break;

		default :
			Assert.fail("Invalid Http Status Code");			
			break;
		}
	}

	// Verify Get API Response using POJO class
	public void verifySampleGetAPIResponseUsingPojoClass(DataTable responseTable) {
		String httpCode = responseTable.asMaps().get(0).get("HttpCode");

		responseBody = response.getBody();
		GetAPIParentResponse getAPIResponse = null;

		try {
			getAPIResponse = responseBody.as(GetAPIParentResponse.class);
		} catch(Exception e) {
			e.printStackTrace();
			Assert.fail("Error in getting get api response body");
		}

		switch(httpCode){
		case "200":	
			Assert.assertEquals("Verify Status Code", Integer.parseInt(httpCode), response.statusCode());
			Assert.assertEquals("Verify Page Number", 1, getAPIResponse.page.intValue());
			Assert.assertEquals("Verify Email of the first data ", "george.bluth@reqres.in", getAPIResponse.data.get(0).email);
			break;

		default :
			Assert.fail("Invalid Http Status Code");			
			break;
		}
	}

	//Call Post API
	public void postSampleAPIJSONDetails(DataTable userDetails) {

		String name = userDetails.asMaps().get(0).get("Name");
		String job = userDetails.asMaps().get(0).get("Job");

		postAPIRequest = new PostAPIRequestDTO();
		postAPIRequest.setName(name);
		postAPIRequest.setJob(job);

		response = sendRequest(getCommonSpec().baseUri(PropertiesReader.getInstance().samplePostAPIUrl), RequestType.POST_REQUEST, postAPIRequest);
	}


	// Verify Post API Response Directly  
	public void verifyPostAPIResponseDetailsDirectly(DataTable responseTable){
		String httpCode = responseTable.asMaps().get(0).get("HttpCode");

		switch(httpCode){
		case "200":	
		case "201":	
			SerenityRest.restAssuredThat(response -> response.statusCode(Integer.parseInt(httpCode)));
			SerenityRest.restAssuredThat(response -> response.body("name", equalTo(postAPIRequest.getName())));
			SerenityRest.restAssuredThat(response -> response.body("job", equalTo(postAPIRequest.getJob())));
			break;

		default :
			Assert.fail("Invalid Http Status Code");			
			break;
		}
	}

	// Verify Post API Response using POJO class
	public void verifyPostAPIResponseDetailsUsingPojoClass(DataTable responseTable){
		String httpCode = responseTable.asMaps().get(0).get("HttpCode");

		responseBody = response.getBody();
		PostAPIParentResponse postAPIResponse = null;

		try {
			postAPIResponse = responseBody.as(PostAPIParentResponse.class);
		} catch(Exception e) {
			e.printStackTrace();
			Assert.fail("Error in getting post api response body");
		}

		switch(httpCode){
		case "200":	
		case "201":	
			Assert.assertEquals("Verify Status Code", Integer.parseInt(httpCode), response.statusCode());
			Assert.assertEquals("Verify Name", postAPIRequest.getName(), postAPIResponse.name);
			Assert.assertEquals("Verify Job ", postAPIRequest.getJob(), postAPIResponse.job);
			break;

		default :
			Assert.fail("Invalid Http Status Code");			
			break;
		}
	}

}
