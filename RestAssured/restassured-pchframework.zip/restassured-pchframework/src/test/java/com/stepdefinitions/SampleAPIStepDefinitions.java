package com.stepdefinitions;

import com.steps.SampleAPISteps;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.steps.ScenarioSteps;

public class SampleAPIStepDefinitions extends ScenarioSteps {
	
	SampleAPISteps sampleAPISteps = new SampleAPISteps();
	
	@When("Get Sample API JSON Details")
	public void getSampleAPIJSONDetails() {
		sampleAPISteps.getSampleAPIJSONDetails();
	}
	
	@Then("Verify Get API JSON Response")
	public void verifySampleJSONResponse(DataTable statusCodeDetails) {
		sampleAPISteps.verifySampleGetAPIResponseDirectly(statusCodeDetails);
		sampleAPISteps.verifySampleGetAPIResponseUsingPojoClass(statusCodeDetails);
	}
	
	@When("Post Sample API JSON Details")
	public void postSampleAPIJSONDetails(DataTable userDetails) {
		sampleAPISteps.postSampleAPIJSONDetails(userDetails);
	}
	
	@Then("Verify Post API JSON Response")
	public void verifyPostAPIJSONResponse(DataTable statusCodeDetails) {
		sampleAPISteps.verifyPostAPIResponseDetailsDirectly(statusCodeDetails);	
		sampleAPISteps.verifyPostAPIResponseDetailsUsingPojoClass(statusCodeDetails);
	}

}
