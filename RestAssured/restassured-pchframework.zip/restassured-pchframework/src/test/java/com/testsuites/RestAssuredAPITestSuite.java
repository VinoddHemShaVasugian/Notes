package com.testsuites;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
		glue = "com.stepdefinitions",
		features = {
				"src/test/resources/features/API/SampleTestAPI.feature"
		},
		plugin = {"rerun:target/SampleTestAPI.txt"},
		stepNotifications = true
		)
public class RestAssuredAPITestSuite {
	
}
