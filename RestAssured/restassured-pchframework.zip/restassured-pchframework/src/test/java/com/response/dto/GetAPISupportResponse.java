package com.response.dto;

public class GetAPISupportResponse {

	public String url;
	public String text;
}
