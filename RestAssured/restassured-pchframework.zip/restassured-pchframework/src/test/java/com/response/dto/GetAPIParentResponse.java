package com.response.dto;

import java.util.List;

public class GetAPIParentResponse {
	
	public Integer page;
	public Integer per_page;
	public Integer total;
	public Integer total_pages;
	public List<GetAPIDataResponse> data;
	public GetAPISupportResponse support;
}
