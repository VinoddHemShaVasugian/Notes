package com.response.dto;

public class PostAPIParentResponse {

	public String name;
	public String job;
	public String id;
	public String createdAt;
}
